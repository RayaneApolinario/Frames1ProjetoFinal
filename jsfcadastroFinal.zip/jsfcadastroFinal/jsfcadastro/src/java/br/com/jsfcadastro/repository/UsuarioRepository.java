package br.com.jsfcadastro.repository;

import br.com.jsfcadastro.model.PessoaModel;
import br.com.jsfcadastro.util.Conexao;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ray
 */
public class UsuarioRepository extends Conexao{
    
    public List<PessoaModel> buscar(String login){
        List<PessoaModel> listaDePessoas = new ArrayList<PessoaModel>();
        super.inicializa();
        listaDePessoas = super.getSess().createQuery("from PessoaModel where login = '"+login+"'").list();
        super.executar();
        return listaDePessoas;
    }
}
